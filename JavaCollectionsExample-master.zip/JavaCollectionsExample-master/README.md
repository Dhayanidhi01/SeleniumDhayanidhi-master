# JavaCollectionsExample
This repo is used to explain the core concepts of collections
